import React from 'react'
import Header from './header/Header'

const companies = () => {
  return (
    <div>
        <Header/>
    </div>
  )
}

export default companies
